# yahtzee
See runConfig.pdf in doc folder or watch https://drive.google.com/file/d/140XhsHdsh7e3EAFxHE7U9ytdxdIUKs4M/view?usp=sharing 